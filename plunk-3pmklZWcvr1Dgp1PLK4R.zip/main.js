(function() {
  var app = angular.module("vendor-app", []);
})();